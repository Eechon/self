define(function(require) {

  var switchable = require('../src/switchable');

  describe('switchable', function() {

    it('normal usage', function() {

    });
  });

});
