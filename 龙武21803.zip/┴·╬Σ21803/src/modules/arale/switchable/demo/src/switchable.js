define(function(require, exports, module) {

  var switchable;

  module.exports = switchable;

});
