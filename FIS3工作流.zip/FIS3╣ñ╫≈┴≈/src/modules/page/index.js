$(function() {
    console.log(1);    
})